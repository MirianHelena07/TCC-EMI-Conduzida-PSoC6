# Component constraints for C:\Users\eduar\Documents\PSoC Creator\externalWatchDog\externalWD.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\eduar\Documents\PSoC Creator\externalWatchDog\externalWD.cydsn\externalWD.cyprj
# Date: Wed, 04 Oct 2023 19:25:46 GMT
