/*******************************************************************************
* File Name: COUNT_DOWN_TIMER.c
* Version 1.0
*
* Description:
*  This file provides the source code to the API for the COUNT_DOWN_TIMER
*  component
*
********************************************************************************
* Copyright 2016-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "COUNT_DOWN_TIMER.h"

/** Indicates whether or not the COUNT_DOWN_TIMER has been initialized. 
*  The variable is initialized to 0 and set to 1 the first time 
*  COUNT_DOWN_TIMER_Start() is called. This allows the Component to 
*  restart without reinitialization after the first call to 
*  the COUNT_DOWN_TIMER_Start() routine.
*/
uint8_t COUNT_DOWN_TIMER_initVar = 0U;

/** The instance-specific configuration structure. This should be used in the 
*  associated COUNT_DOWN_TIMER_Init() function.
*/ 
cy_stc_tcpwm_counter_config_t const COUNT_DOWN_TIMER_config =
{
        .period = 5000000UL,
        .clockPrescaler = 0UL,
        .runMode = 0UL,
        .countDirection = 0UL,
        .compareOrCapture = 2UL,
        .compare0 = 16384UL,
        .compare1 = 16384UL,
        .enableCompareSwap = false,
        .interruptSources = 1UL,
        .captureInputMode = 3UL,
        .captureInput = CY_TCPWM_INPUT_CREATOR,
        .reloadInputMode = 3UL,
        .reloadInput = CY_TCPWM_INPUT_CREATOR,
        .startInputMode = 3UL,
        .startInput = CY_TCPWM_INPUT_CREATOR,
        .stopInputMode = 3UL,
        .stopInput = CY_TCPWM_INPUT_CREATOR,
        .countInputMode = 3UL,
        .countInput = CY_TCPWM_INPUT_CREATOR,
};


/*******************************************************************************
* Function Name: COUNT_DOWN_TIMER_Start
****************************************************************************//**
*
*  Calls the COUNT_DOWN_TIMER_Init() when called the first time and enables 
*  the COUNT_DOWN_TIMER. For subsequent calls the configuration is left 
*  unchanged and the component is just enabled.
*
* \globalvars
*  \ref COUNT_DOWN_TIMER_initVar
*
*******************************************************************************/
void COUNT_DOWN_TIMER_Start(void)
{
    if (0U == COUNT_DOWN_TIMER_initVar)
    {
        (void)Cy_TCPWM_Counter_Init(COUNT_DOWN_TIMER_HW, COUNT_DOWN_TIMER_CNT_NUM, &COUNT_DOWN_TIMER_config); 

        COUNT_DOWN_TIMER_initVar = 1U;
    }

    Cy_TCPWM_Enable_Multiple(COUNT_DOWN_TIMER_HW, COUNT_DOWN_TIMER_CNT_MASK);
    
    #if (COUNT_DOWN_TIMER_INPUT_DISABLED == 7UL)
        Cy_TCPWM_TriggerStart(COUNT_DOWN_TIMER_HW, COUNT_DOWN_TIMER_CNT_MASK);
    #endif /* (COUNT_DOWN_TIMER_INPUT_DISABLED == 7UL) */    
}


/* [] END OF FILE */
