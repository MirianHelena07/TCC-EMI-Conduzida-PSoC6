/*******************************************************************************
* File Name: countDownTimer.h
* Version 1.0
*
* Description:
*  This file provides constants and parameter values for the countDownTimer
*  component.
*
********************************************************************************
* Copyright 2016-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(countDownTimer_CY_TCPWM_COUNTER_PDL_H)
#define countDownTimer_CY_TCPWM_COUNTER_PDL_H

#include "cyfitter.h"
#include "tcpwm/cy_tcpwm_counter.h"

   
/*******************************************************************************
* Variables
*******************************************************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t  countDownTimer_initVar;
extern cy_stc_tcpwm_counter_config_t const countDownTimer_config;
/** @} group_globals */


/***************************************
*  Conditional Compilation Parameters
***************************************/

#define countDownTimer_INIT_COMPARE_OR_CAPTURE    (2UL)


/***************************************
*        Function Prototypes
****************************************/
/**
* \addtogroup group_general
* @{
*/
void countDownTimer_Start(void);
__STATIC_INLINE cy_en_tcpwm_status_t countDownTimer_Init(cy_stc_tcpwm_counter_config_t const *config);
__STATIC_INLINE void countDownTimer_DeInit(void);
__STATIC_INLINE void countDownTimer_Enable(void);
__STATIC_INLINE void countDownTimer_Disable(void);
__STATIC_INLINE uint32_t countDownTimer_GetStatus(void);

#if(CY_TCPWM_COUNTER_MODE_CAPTURE == countDownTimer_INIT_COMPARE_OR_CAPTURE)
    __STATIC_INLINE uint32_t countDownTimer_GetCapture(void);
    __STATIC_INLINE uint32_t countDownTimer_GetCaptureBuf(void);
#else
    __STATIC_INLINE void countDownTimer_SetCompare0(uint32_t compare0);
    __STATIC_INLINE uint32_t countDownTimer_GetCompare0(void);
    __STATIC_INLINE void countDownTimer_SetCompare1(uint32_t compare1);
    __STATIC_INLINE uint32_t countDownTimer_GetCompare1(void);
    __STATIC_INLINE void countDownTimer_EnableCompareSwap(bool enable);
#endif /* (CY_TCPWM_COUNTER_MODE_CAPTURE == countDownTimer_INIT_COMPARE_OR_CAPTURE) */

__STATIC_INLINE void countDownTimer_SetCounter(uint32_t count);
__STATIC_INLINE uint32_t countDownTimer_GetCounter(void);
__STATIC_INLINE void countDownTimer_SetPeriod(uint32_t period);
__STATIC_INLINE uint32_t countDownTimer_GetPeriod(void);
__STATIC_INLINE void countDownTimer_TriggerStart(void);
__STATIC_INLINE void countDownTimer_TriggerReload(void);
__STATIC_INLINE void countDownTimer_TriggerStop(void);
__STATIC_INLINE void countDownTimer_TriggerCapture(void);
__STATIC_INLINE uint32_t countDownTimer_GetInterruptStatus(void);
__STATIC_INLINE void countDownTimer_ClearInterrupt(uint32_t source);
__STATIC_INLINE void countDownTimer_SetInterrupt(uint32_t source);
__STATIC_INLINE void countDownTimer_SetInterruptMask(uint32_t mask);
__STATIC_INLINE uint32_t countDownTimer_GetInterruptMask(void);
__STATIC_INLINE uint32_t countDownTimer_GetInterruptStatusMasked(void);
/** @} general */


/***************************************
*           API Constants
***************************************/

/**
* \addtogroup group_macros
* @{
*/
/** This is a ptr to the base address of the TCPWM instance */
#define countDownTimer_HW                 (countDownTimer_TCPWM__HW)

/** This is a ptr to the base address of the TCPWM CNT instance */
#define countDownTimer_CNT_HW             (countDownTimer_TCPWM__CNT_HW)

/** This is the counter instance number in the selected TCPWM */
#define countDownTimer_CNT_NUM            (countDownTimer_TCPWM__CNT_IDX)

/** This is the bit field representing the counter instance in the selected TCPWM */
#define countDownTimer_CNT_MASK           (1UL << countDownTimer_CNT_NUM)
/** @} group_macros */

#define countDownTimer_INPUT_MODE_MASK    (0x3U)
#define countDownTimer_INPUT_DISABLED     (7U)


/*******************************************************************************
* Function Name: countDownTimer_Init
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_tcpwm_status_t countDownTimer_Init(cy_stc_tcpwm_counter_config_t const *config)
{
    return(Cy_TCPWM_Counter_Init(countDownTimer_HW, countDownTimer_CNT_NUM, config));
}


/*******************************************************************************
* Function Name: countDownTimer_DeInit
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_DeInit(void)                   
{
    Cy_TCPWM_Counter_DeInit(countDownTimer_HW, countDownTimer_CNT_NUM, &countDownTimer_config);
}

/*******************************************************************************
* Function Name: countDownTimer_Enable
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Enable_Multiple() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_Enable(void)                   
{
    Cy_TCPWM_Enable_Multiple(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_Disable
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Disable_Multiple() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_Disable(void)                  
{
    Cy_TCPWM_Disable_Multiple(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_GetStatus
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_GetStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetStatus(void)                
{
    return(Cy_TCPWM_Counter_GetStatus(countDownTimer_HW, countDownTimer_CNT_NUM));
}


#if(CY_TCPWM_COUNTER_MODE_CAPTURE == countDownTimer_INIT_COMPARE_OR_CAPTURE)
    /*******************************************************************************
    * Function Name: countDownTimer_GetCapture
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_GetCapture() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE uint32_t countDownTimer_GetCapture(void)               
    {
        return(Cy_TCPWM_Counter_GetCapture(countDownTimer_HW, countDownTimer_CNT_NUM));
    }


    /*******************************************************************************
    * Function Name: countDownTimer_GetCaptureBuf
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_GetCaptureBuf() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE uint32_t countDownTimer_GetCaptureBuf(void)            
    {
        return(Cy_TCPWM_Counter_GetCaptureBuf(countDownTimer_HW, countDownTimer_CNT_NUM));
    }
#else
    /*******************************************************************************
    * Function Name: countDownTimer_SetCompare0
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_SetCompare0() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE void countDownTimer_SetCompare0(uint32_t compare0)      
    {
        Cy_TCPWM_Counter_SetCompare0(countDownTimer_HW, countDownTimer_CNT_NUM, compare0);
    }


    /*******************************************************************************
    * Function Name: countDownTimer_GetCompare0
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_GetCompare0() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE uint32_t countDownTimer_GetCompare0(void)              
    {
        return(Cy_TCPWM_Counter_GetCompare0(countDownTimer_HW, countDownTimer_CNT_NUM));
    }


    /*******************************************************************************
    * Function Name: countDownTimer_SetCompare1
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_SetCompare1() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE void countDownTimer_SetCompare1(uint32_t compare1)      
    {
        Cy_TCPWM_Counter_SetCompare1(countDownTimer_HW, countDownTimer_CNT_NUM, compare1);
    }


    /*******************************************************************************
    * Function Name: countDownTimer_GetCompare1
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_GetCompare1() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE uint32_t countDownTimer_GetCompare1(void)              
    {
        return(Cy_TCPWM_Counter_GetCompare1(countDownTimer_HW, countDownTimer_CNT_NUM));
    }


    /*******************************************************************************
    * Function Name: countDownTimer_EnableCompareSwap
    ****************************************************************************//**
    *
    * Invokes the Cy_TCPWM_Counter_EnableCompareSwap() PDL driver function.
    *
    *******************************************************************************/
    __STATIC_INLINE void countDownTimer_EnableCompareSwap(bool enable)  
    {
        Cy_TCPWM_Counter_EnableCompareSwap(countDownTimer_HW, countDownTimer_CNT_NUM, enable);
    }
#endif /* (CY_TCPWM_COUNTER_MODE_CAPTURE == countDownTimer_INIT_COMPARE_OR_CAPTURE) */


/*******************************************************************************
* Function Name: countDownTimer_SetCounter
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_SetCounter() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_SetCounter(uint32_t count)          
{
    Cy_TCPWM_Counter_SetCounter(countDownTimer_HW, countDownTimer_CNT_NUM, count);
}


/*******************************************************************************
* Function Name: countDownTimer_GetCounter
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_GetCounter() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetCounter(void)               
{
    return(Cy_TCPWM_Counter_GetCounter(countDownTimer_HW, countDownTimer_CNT_NUM));
}


/*******************************************************************************
* Function Name: countDownTimer_SetPeriod
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_SetPeriod() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_SetPeriod(uint32_t period)          
{
    Cy_TCPWM_Counter_SetPeriod(countDownTimer_HW, countDownTimer_CNT_NUM, period);
}


/*******************************************************************************
* Function Name: countDownTimer_GetPeriod
****************************************************************************//**
*
* Invokes the Cy_TCPWM_Counter_GetPeriod() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetPeriod(void)                
{
    return(Cy_TCPWM_Counter_GetPeriod(countDownTimer_HW, countDownTimer_CNT_NUM));
}


/*******************************************************************************
* Function Name: countDownTimer_TriggerStart
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_TriggerStart(void)             
{
    Cy_TCPWM_TriggerStart(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_TriggerReload
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerReloadOrIndex() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_TriggerReload(void)     
{
    Cy_TCPWM_TriggerReloadOrIndex(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_TriggerStop
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerStopOrKill() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_TriggerStop(void)
{
    Cy_TCPWM_TriggerStopOrKill(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_TriggerCapture
****************************************************************************//**
*
* Invokes the Cy_TCPWM_TriggerCaptureOrSwap() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_TriggerCapture(void)     
{
    Cy_TCPWM_TriggerCaptureOrSwap(countDownTimer_HW, countDownTimer_CNT_MASK);
}


/*******************************************************************************
* Function Name: countDownTimer_GetInterruptStatus
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetInterruptStatus(void)       
{
    return(Cy_TCPWM_GetInterruptStatus(countDownTimer_HW, countDownTimer_CNT_NUM));
}


/*******************************************************************************
* Function Name: countDownTimer_ClearInterrupt
****************************************************************************//**
*
* Invokes the Cy_TCPWM_ClearInterrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_ClearInterrupt(uint32_t source)     
{
    Cy_TCPWM_ClearInterrupt(countDownTimer_HW, countDownTimer_CNT_NUM, source);
}


/*******************************************************************************
* Function Name: countDownTimer_SetInterrupt
****************************************************************************//**
*
* Invokes the Cy_TCPWM_SetInterrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_SetInterrupt(uint32_t source)
{
    Cy_TCPWM_SetInterrupt(countDownTimer_HW, countDownTimer_CNT_NUM, source);
}


/*******************************************************************************
* Function Name: countDownTimer_SetInterruptMask
****************************************************************************//**
*
* Invokes the Cy_TCPWM_SetInterruptMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void countDownTimer_SetInterruptMask(uint32_t mask)     
{
    Cy_TCPWM_SetInterruptMask(countDownTimer_HW, countDownTimer_CNT_NUM, mask);
}


/*******************************************************************************
* Function Name: countDownTimer_GetInterruptMask
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptMask() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetInterruptMask(void)         
{
    return(Cy_TCPWM_GetInterruptMask(countDownTimer_HW, countDownTimer_CNT_NUM));
}


/*******************************************************************************
* Function Name: countDownTimer_GetInterruptStatusMasked
****************************************************************************//**
*
* Invokes the Cy_TCPWM_GetInterruptStatusMasked() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t countDownTimer_GetInterruptStatusMasked(void)
{
    return(Cy_TCPWM_GetInterruptStatusMasked(countDownTimer_HW, countDownTimer_CNT_NUM));
}

#endif /* countDownTimer_CY_TCPWM_COUNTER_PDL_H */


/* [] END OF FILE */
