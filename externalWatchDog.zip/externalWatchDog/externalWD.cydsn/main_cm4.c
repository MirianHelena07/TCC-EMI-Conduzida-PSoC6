#include "project.h"
#include <stdio.h>
//prototypes
void initInterrupts();
void restartTestPsoc();

//gloabal variables
static uint32_t counter = 0; //us
static bool restartDevice = false;
//functions

//external interrupt 
void aliveSignalInterrupt(){   
    counter++;
    //CyDelay(1000);
    //UART_PutString("DCR");
    
    //Cy_GPIO_ClearInterrupt(ALIVE_SIGNAL_0_PORT, ALIVE_SIGNAL_0_NUM);
    
}
//***************************************************************

//timer interrupt, 1ms
void timerInterrupt(){
    //char buffer[10]={0};
    
    //sprintf(buffer, "Counter-%i\n", (int)(counter&0xFFFF) );
    //UART_PutString(buffer);
    if(counter == 0 || restartDevice){
        //warns PC program    
        if(!restartDevice) {
            UART_PutString("CR");//controll, restart
            while(!UART_IsTxComplete());
        }

        restartTestPsoc();    
        restartDevice = false;
        CyDelay(3E3); //waits device restart

        
    }
    counter = 0;
    
    
    //clear interrupt flag
    COUNT_DOWN_TIMER_ClearInterrupt(COUNT_DOWN_TIMER_GetInterruptStatusMasked());    
}
//***************************************************************

int main(void) {   

    initInterrupts(); 
    UART_Start();

    Cy_GPIO_Write(RED_LED_0_PORT, RED_LED_0_NUM, 0); //pull-up
    
    uint8_t buff = 0, n=0;
    do{
        while(UART_Get() != 'H'){ //waits host message            
            UART_PutString("CW"); //warns host that its wating
            while(!UART_IsTxComplete());
            CyDelay(500);
            
        }
        
        n = buff = 0;
        while( (buff = UART_Get() )!= 'S' && n < 10){
            CyDelayUs(10);
            n++;
        }
       
    }while(buff != 'S'); //waits start signal
    CyDelay(1);
    UART_PutString("CS"); //confirm start to host
    while(!UART_IsTxComplete());
    
    Cy_GPIO_Write(RED_LED_0_PORT, RED_LED_0_NUM, 1); //pull-up
    
    COUNT_DOWN_TIMER_Start();
    while(1){         

        while(UART_Get() != 'H');
        
        uint8_t buff = 0, n=0;
        while( (buff = UART_Get() )!= 'R' && n < 10){
            CyDelayUs(10);
            n++;
        }
        if(buff == 'R'){  
            //UART_PutString("AAA");
            restartDevice = true;
            //restartTestPsoc(); 

        }


        
    }
}
//***************************************************************

void initInterrupts(){
    __enable_irq(); // Enable global interrupts.
   
    Cy_SysInt_Init(&EXTERNAL_IRS_cfg, aliveSignalInterrupt);
    NVIC_EnableIRQ(EXTERNAL_IRS_cfg.intrSrc);
    
    Cy_SysInt_Init(&TIMER_IRS_cfg, timerInterrupt);
    NVIC_EnableIRQ(TIMER_IRS_cfg.intrSrc);
    //ALIVE_SIGNAL
    
}
//****************************************************************
void restartTestPsoc(){
    
    Cy_GPIO_Write(RESET_SIGNAL_0_PORT, RESET_SIGNAL_0_NUM, 0);
    CyDelayUs(10);
    //CyDelay(10);//ms
    Cy_GPIO_Write(RESET_SIGNAL_0_PORT, RESET_SIGNAL_0_NUM, 1);    
    
}
//****************************************************************



