import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy import stats

def reject_outliers(data, m = 4.):
    d = np.abs(data - np.median(data))
    mdev = np.median(d)
    s = d/mdev if mdev else np.zeros(len(d))
    return data[s<m]

def parse_file(path, out_file):

    file = open(path, "r")

    # numero de samples total
    sample_size = 10000

    # database de samples todas as frequencias
    samples_db = []
    ref_samples_db  = []

    # contagem de samples para controlar o loop
    sample_count = 0

    for i, line in enumerate(file):

        # para pular o cabeçalho
        if i < 5:
            continue

        # se chegou no numero de frequencias desejadas, termina o loop
        if sample_count == sample_size:
            break

        # pegando o conteudo da linha
        sample = line.split()
        samples_db.append(int(sample[1]))
        ref_samples_db.append(int(sample[2]))

        sample_count = sample_count + 1

    # removing outliers
    print("Número de dados antes de filtrar os outliers:" + str(len(samples_db)))
    samples_db = reject_outliers(np.array(samples_db))
    print("Número de dados depois de filtrar os outliers:" + str(len(samples_db)))

    # desvio padrao e de media
    std_dev = np.std(samples_db)

    # calculando o erro quadratico medio
    error_db = [(x-4084)**2 for x in samples_db]
    mean_error_db = np.mean(error_db)

    # calculando a moda dos dados
    mode = stats.mode(samples_db)
    print("Moda dos dados: ",  mode)

    # calculando a media do erro quadratico medio
    mean = np.mean(samples_db)
    print("Media dos dados: ",  mean)

    # calculando valor maximo e minimo
    max = np.max(samples_db)
    print("Valor Maximo: ",  max)

    # calculando valor maximo e minimo
    min = np.min(samples_db)
    print("Valor Minimo: ",  min)

    # calculando mediana
    median = np.median(samples_db)
    print("Mediana: ",  median)

    # histograma
    fig = plt.figure(figsize=(20,8))
    
    labels, counts = np.unique(samples_db, return_counts=True)
    plt.bar(labels, counts)
    plt.gca().set_xticks(labels)

    plt.ylabel ('Número de Ocorrências')
    plt.xlabel ('Valor Medido')
    plt.xticks(rotation = 40)
    n = 3
    [l.set_visible(False) for (i,l) in enumerate(plt.gca().get_xticklabels()) if i % n != 0]

    plt.title ('Vin = 3.29V (digital: 4084)' +"\n" + "Frequência = 550KHz")

    #plt.grid()
    plt.savefig("Range_I/Hist_550KHz.svg", format = 'svg')
    plt.show()

    with open(out_file, 'w') as f:
        f.write("Desvio Padrão: " + str(std_dev) + "\n")
        f.write("Erro Quadrático Médio: " + str(mean_error_db) + "\n")
        f.write("Média: " + str(mean) + "\n")
        f.write("Valor Máximo: " + str(max) + "\n")
        f.write("Valor Mínimo: " + str(min) + "\n")
        f.write("Mediana: " + str(median) + "\n")
    
def main():

    parse_file("Range_I/550KHz.txt", "Range_I/out_550KHz.txt")

    return 0


if __name__ == '__main__':
    main() 