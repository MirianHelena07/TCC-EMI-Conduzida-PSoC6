import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy import stats

def parse_file(path, n_freq, ref_std_dev, ref_mean_error, freq_base, freq_step):

    file = open(path, "r")

    # numero de samples de cada frequencia
    freq_sample_size = 3000

    # listas auxiliares que serao re-preenchidas para cada frequencia
    freq_samples  = []
    ref_samples   = []

    # database de samples todas as frequencias
    freq_samples_db = []
    ref_samples_db  = []

    # database do desvio padrao de todas as frequencias
    freq_std_dev_db = []
    freq_mean_db    = []
    freq_mean_error_db = []
    freq_num_above_ref_std_dev_db = []

    # contagem de linhas e de qtd de frequencias para controlar o loop
    line_count = 0
    freq_count = 0

    # lista auxiliar para o plot
    idx_list    = []
    freq_list   = []

    for i, line in enumerate(file):

        # para pular o cabeçalho
        if i < 5:
            continue

        # se chegou no numero de frequencias desejadas, termina o loop
        if freq_count == n_freq:
            break

        # pegando o conteudo da linha
        sample = line.split()
        freq_samples.append(int(sample[1]))
        ref_samples.append(int(sample[2]))

        if line_count == (freq_sample_size-1):
            line_count = 0
            freq_count = freq_count + 1

            freq_samples_db.append(freq_samples)
            ref_samples_db.append(ref_samples)
            freq_samples    = []
            ref_samples     = []

        else:
            line_count = line_count + 1

    # lista de desvio padrao e de media por frequencia
    for i in range(n_freq):
        freq_std_dev_db.append(np.std(freq_samples_db[i]))
        freq_mean_db.append(np.mean(freq_samples_db[i]))
        idx_list.append(i)

    error_count = 0

    # lista com numero de samples com erro maior do que o desvio padrão de referência, por frequencia medida
    for i in range(n_freq):
        for j in range(freq_sample_size):
            if abs(freq_samples_db[i][j] - 2048) > ref_std_dev:
                error_count = error_count + 1
        freq_num_above_ref_std_dev_db.append(error_count)
        error_count = 0

    # calculando o erro medio
    for i in range(n_freq):
        #freq_error_db = [np.absolute(x-2048) for x in freq_samples_db[i]]
        #freq_error_db = [np.absolute(x-2048)-ref_mean_error for x in freq_samples_db[i]]
        freq_error_db = [(x-2048)**2 for x in freq_samples_db[i]]
        freq_mean_error_db.append(np.mean(freq_error_db))

    # calculando a moda do erro quadratico medio
    freq_mean_error_db_mode = stats.mode(freq_mean_error_db)

    # criando os valores do eixo y
    current_freq = freq_base
    for i in range(n_freq):
        freq_list.append(current_freq)
        current_freq = current_freq + freq_step

    fig1 = plt.figure(figsize=(20,8))
    #fig1 = plt.figure()

    # grafico da media
    #plt.scatter(freq_list, freq_mean_db, label = "Desvio padrao por frequencia", color='r')

    # grafico do erro medio em relação a 2048
    #graph = plt.scatter(freq_list, freq_mean_error_db, label = "Desvio padrao por frequencia", color='r')

    # grafico desvio padrao
    #plt.scatter(freq_list, freq_std_dev_db, label = "Desvio padrao por frequencia", color='r')

    # grafico de numero de samples acima do desvio padrao de referencia
    #plt.scatter(freq_list, freq_num_above_ref_std_dev_db, label = "Desvio padrao por frequencia", color='r')

    plt.xticks(freq_list, rotation = 20)
    #n = 3
    #[l.set_visible(False) for (i,l) in enumerate(plt.gca().get_xticklabels()) if i % n != 0]

    plt.ylabel ('Erro quadrático médio em relação a 2048')
    plt.xlabel ('Frequência (kHz)')
    plt.title ('Range I')

    #plt.rcParams.update({'font.size': 1})
    #plt.grid()
    plt.savefig("RangeI_erro_med_2048.svg", format = 'svg')
    plt.show()
    


    

def parse_file_no_injection(path):

    file = open(path, "r")

    data_read  = []
    data_ref   = []
    idx_list   = []
    idx_sample = 0

    for i, line in enumerate(file):

        # para pular o cabeçalho do log
        if i < 5:
            #print("Index : " + str(i))
            #print("Line : " + line)
            continue

        # criando a lista com as samples para o eixo y
        sample = line.split()
        data_read.append(int(sample[1]))
        data_ref.append(int(sample[2]))

        # criando a lista com os indices para o eixo x
        idx_list.append(idx_sample)
        idx_sample = idx_sample + 1

    #fig1 = plt.figure(figsize=(3000,6))

    # calculo de estatisticas dos dados lidos (desvio padrao, moda, minimo, maximo, etc)
    std_devtiation = np.std(data_read)
    maxValue = np.max(data_read)
    minValue = np.min(data_read)

    # mean error
    error = [x-2048 for x in data_read]
    mean_error = np.mean(np.absolute(error))

    # erro quadrático médio
    error = [(x-2048)**2 for x in data_read]
    meanQ_error = np.mean(error)   

    print("Erro quadratico medio = ", meanQ_error)

    # histogram of read data
    fig = plt.figure(figsize=(13,7))
    plt.figtext(0.14, 0.83, f"Erro quadrático médio = {meanQ_error:.2f}")
    labels, counts = np.unique(data_read, return_counts=True)
    plt.bar(labels, counts, align='center')
    plt.gca().set_xticks(labels)

    plt.ylabel ('Número de Ocorrências')
    #plt.yticks (np.arange(0,len(data_read)+2500,2500))
    plt.xlabel ('Medição')
    plt.title ('Histograma das Medições do ADC, sem Injeção de Erro + Setup disconectado')
   

    plt.savefig("no_injection_no_conn.svg", format = 'svg')
    plt.show()

    # tentativa de scatter, nao funfou bem
    #plt.scatter(idx_list, data_ref, label = "Dado Escrito", color='r')
    #plt.scatter(idx_list, data_read, label = "Dado Lido", color='b')
    #listOf_Yticks = np.arange(0, len(data_read),1)
    #plt.yticks(listOf_Yticks)
    #listOf_Xticks = np.arange(0, len(data_read) + len(data_read)/10, len(data_read)/10)
    #plt.xticks(listOf_Xticks)


    return mean_error, std_devtiation
    
def main():

    parse_file_no_injection("no_injection_100_buff_no_conn_rf.txt")

    #parse_file("range_I.txt", 10, std_dev, mean_error, 150, 100)
    #parse_file("range_II.txt", 100, std_dev, mean_error, 1, 1)
    #parse_file("range_III.txt", 91, std_dev, mean_error, 100, 10)
    

    return 0


if __name__ == '__main__':
    main() 