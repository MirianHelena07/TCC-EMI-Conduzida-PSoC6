import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy import stats

def reject_outliers(data, m=5000.):
    # Ensure the input is a NumPy array
    data = np.array(data)
    
    # Check for empty data
    if len(data) == 0:
        raise ValueError("Input data is empty")
    
    # Calculate the median of the data
    median = np.median(data)
    
    # Compute the absolute deviations from the median
    d = np.abs(data - median)
    
    # Compute the median absolute deviation (MAD)
    mdev = np.median(d)
    
    # Avoid division by zero, return zeros if mdev is 0
    s = d / mdev if mdev else np.zeros(len(d))
    
    # Replace outliers with 0
    data[s >= m] = 0

    # calculating number of replacements
    replacements = data[s >= m]
    if len(replacements):
        print("Replacements " + str(len(replacements)))
    
    return data

def parse_file(path, n_freq, freq_base, freq_step):

    file = open(path, "r")

    # numero de samples de cada frequencia
    freq_sample_size = 3000

    # listas auxiliares que serao re-preenchidas para cada frequencia
    freq_samples  = []
    ref_samples   = []

    # database de samples todas as frequencias
    freq_samples_db = []
    ref_samples_db  = []

    # database do desvio padrao de todas as frequencias
    freq_mean_db    = []
    freq_mean_error_db = []

    # contagem de linhas e de qtd de frequencias para controlar o loop
    line_count = 0
    freq_count = 0

    # lista auxiliar para o plot
    freq_list   = []

    for i, line in enumerate(file):

        # para pular o cabeçalho
        if i < 5:
            continue

        # se chegou no numero de frequencias desejadas, termina o loop
        if freq_count == n_freq:
            break

        # pegando o conteudo da linha
        sample = line.split()
        freq_samples.append(int(sample[1]))
        ref_samples.append(int(sample[2]))

        if line_count == (freq_sample_size-1):
            line_count = 0
            freq_count = freq_count + 1

            freq_samples_db.append(freq_samples)
            ref_samples_db.append(ref_samples)
            freq_samples    = []
            ref_samples     = []

        else:
            line_count = line_count + 1

    # calculando o erro medio
    for i in range(n_freq):
        freq_error_db = [(x-2048)**2 for x in freq_samples_db[i]]
        freq_error_db = reject_outliers(freq_error_db)
        freq_mean_error_db.append(np.mean(freq_error_db))

    # criando os valores do eixo y
    current_freq = freq_base
    for i in range(n_freq):
        freq_list.append(current_freq)
        current_freq = current_freq + freq_step

    fig1 = plt.figure(figsize=(20,8))
    #fig1 = plt.figure()

    # grafico da media
    #plt.scatter(freq_list, freq_mean_db, label = "Desvio padrao por frequencia", color='r')

    # grafico do erro medio em relação a 2048
    graph = plt.scatter(freq_list, freq_mean_error_db, label = "Erro quadratico Medio", color='r')

    # grafico desvio padrao
    #plt.scatter(freq_list, freq_std_dev_db, label = "Desvio padrao por frequencia", color='r')

    plt.xticks(freq_list, rotation = 20)
    n = 3
    [l.set_visible(False) for (i,l) in enumerate(plt.gca().get_xticklabels()) if i % n != 0]

    plt.ylabel ('Erro quadrático médio em relação a 2048')
    plt.xlabel ('Frequência (kHz)')
    plt.title ('Range III')

    #plt.rcParams.update({'font.size': 1})
    #plt.grid()
    plt.savefig("RangeI_erro_med_2048.svg", format = 'svg')
    plt.show()
    
def main():

    #parse_file("range_I.txt", 10, std_dev, mean_error, 150, 100)
    #parse_file("range_II.txt", 100, std_dev, mean_error, 1, 1)
    parse_file("range_III.txt", 91, 100, 10)
    
    return 0

if __name__ == '__main__':
    main() 