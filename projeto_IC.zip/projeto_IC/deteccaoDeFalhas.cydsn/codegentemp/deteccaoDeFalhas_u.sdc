# Component constraints for C:\PC_vini\executaveis\3 - programas_finais_padrao_buffcont_Vcte\projeto_IC\deteccaoDeFalhas.cydsn\TopDesign\TopDesign.cysch
# Project: C:\PC_vini\executaveis\3 - programas_finais_padrao_buffcont_Vcte\projeto_IC\deteccaoDeFalhas.cydsn\deteccaoDeFalhas.cyprj
# Date: Thu, 01 Aug 2024 23:17:17 GMT
