// Projeto iniciacao cientifica PSoc6 2023 - Eduardo Fabbris

//====================== INCLUDES =====================

#include "gheader.h"
#include "deteccaoDeFalhas_files\buffer.h"
#include "deteccaoDeFalhas_files\trainingData.h"
#include "deteccaoDeFalhas_files\serial.h"

//================= GLOBAL VARIABLES ==================
BUFFER_DATA buffer;
REFERENCE_VALUES reference;
extern uint32_t triangularWaveLUT;


//===================== FUNCTIONS =====================

int main(void) {
    
    initDevices();
#if PSOC_MONITOR_ON
    //start warning led
    Cy_GPIO_Write(RED_LED_0_PORT, RED_LED_0_NUM, 0); //pull-up
    
    uint8_t buff = 0, n=0;
    do{
        while(UART_Get() != 'H'){ //waits host message            
            UART_PutString("MW"); //warns host that it's wating
            while(!UART_IsTxComplete());
            CyDelay(500);           
        }
        
        n = buff = 0;
        while( (buff = UART_Get() )!= 'S' && n < 10){
            CyDelayUs(10);
            n++;
        }
       
    }while(buff != 'S'); //waits start signal
    
    CyDelay(1);
    UART_PutString("MS"); //confirm start to host
    while(!UART_IsTxComplete());
    Cy_GPIO_Write(RED_LED_0_PORT, RED_LED_0_NUM, 1);//pull-up
#endif

    buffer.cycleIndex = 0;
     
    //bias
    Stopwatch_TriggerStart(); //starts timer
    ADC_StartConvert(); //starts adc conversion         
    

    while(1);
}


//interrupt -> the function is called every time it finishes a conversion
void ADC_ISR_Callback(void)
{
#if PSOC_MONITOR_ON
    static uint32_t UART_aliveSignalCounter = 0;
#endif
    static uint16_t nextValue;
    static bool firstConv = true;

    //stop stopwatch
    Stopwatch_TriggerStop();
    
    
    //if buffer is not full yet
    if(buffer.dataIndex < MAX_BUFFER_DATA) {

        //first value is neglected 
        if(!firstConv) {
            //gets DAC value
            buffer.data[buffer.dataIndex].written = nextValue;     
            
            //gets ADC value
            buffer.data[buffer.dataIndex].read =  ADC_GetResult16(0);      

            //gets time
            buffer.data[buffer.dataIndex].dtime = Stopwatch_GetCounter();       
 
            buffer.dataIndex++;
        }  
        else {

            firstConv = false;    
        }
                
    }  
    else {
#if PSOC_MONITOR_ON
        //alive signal
        Cy_GPIO_Write(ALIVE_SIGNAL_0_PORT, ALIVE_SIGNAL_0_NUM, 1);
        
        //serial alive signal
        if(UART_aliveSignalCounter < 2E3){
            UART_aliveSignalCounter++;
        }
        else{
            UART_PutString("MA");
            while(!UART_IsTxComplete());
            UART_aliveSignalCounter = 0;   
        }
#endif           
        if(reference.cycleIndex < MAX_REFERENCE_VALUES_CYCLE) {          
            getReferenceValues();
            #if DEBUG_CODE    
                UARTPrintData(); //print training data
            #endif 
            reference.cycleIndex++;        


        } else if(buffer.cycleIndex < MAX_BUFFER_DATA_CYCLE || !DEBUG_CODE) {
            
            UARTPrintData();
            //if a error is found. -> i.e., sends all data only if a fault is detected to plot the curve
            //if(verifyFaults() || DEBUG_CODE){
                
        

                
                // Reset visual warning    
                //for(int i=0; i <2*3; i++){
                //    Cy_GPIO_Inv(GREEN_LED_0_PORT, GREEN_LED_0_NUM);
                //    CyDelay(250);   
                //}
                    
                //reset kit with watchdog
                //WD_reset_Start();

            //} 
            
            buffer.cycleIndex++;
          } 
        

        buffer.dataIndex = 0; 
        firstConv = true;
#if PSOC_MONITOR_ON
        Cy_GPIO_Write(ALIVE_SIGNAL_0_PORT, ALIVE_SIGNAL_0_NUM, 0);
#endif
    }

    //stopwatch
    Stopwatch_TriggerReload();//reload 
    Stopwatch_TriggerStart();//starts again     
    
    //starts again another conversion
    nextValue = CTDAC0->CTDAC_VAL_NXT; //stores the next value in DAC
    
    //if(Cy_GPIO_Read(Button_0_PORT, Button_0_NUM)) nextValue ^= (1 << 5);
    ADC_StartConvert();

}


void initDevices(){

    __enable_irq(); // Enable global interrupts. 
    
    //UART
    UART_Start();

    //Timer
    Stopwatch_Init(&Stopwatch_config);
    Stopwatch_Enable();

    //DMA
    DMA1_Start(&triangularWaveLUT, (uint32_t *)&(CTDAC0->CTDAC_VAL_NXT));

    //DAC
    DAC_Start();  
    
    //ADC
    ADC_Start();   
    ADC_IRQ_Enable();    
}







